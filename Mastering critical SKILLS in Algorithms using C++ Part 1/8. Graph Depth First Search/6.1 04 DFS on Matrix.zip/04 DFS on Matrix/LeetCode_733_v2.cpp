#include<iostream>
#include<vector>
using namespace std;

class Solution {
public:
	// Return true if this position INSIDE the 2D matrix
	bool isvalid(int r, int c, vector<vector<int>> &matrix) {
		if (r < 0 || r >= (int) matrix.size())
			return false;
		if (c < 0 || c >= (int) matrix[0].size())
			return false;
		return true;
	}
	void dfs(int r, int c, vector<vector<int>> &matrix, vector<vector<bool>> &visited, int oldcolor, int newcolor) {
		if (!isvalid(r, c, matrix) || visited[r][c] || matrix[r][c] != oldcolor)
			return;
			
		visited[r][c] = true, matrix[r][c] = newcolor;
		int dr[] { -1, 0, 1, 0 };	// Delta for: up, right, down, left
		int dc[] { 0, 1, 0, -1 };
		for (int d = 0; d < 4; ++d)
			dfs(r + dr[d], c + dc[d], matrix, visited, oldcolor, newcolor);
	}

	vector<vector<int>> floodFill(vector<vector<int>> &image, int sr, int sc, int newColor) {
		// RxC boolean grid. Assume columns > 0
		vector<vector<bool>> visited(image.size(), vector<bool>(image[0].size()));
		dfs(sr, sc, image, visited, image[sr][sc], newColor);

		return image;
	}
};

int main() {

	return 0;
}
