#include<iostream>
#include<vector>
#include<algorithm>
#include<climits>
using namespace std;

int main() {

	vector<int> v { 2, 2, 2, 3, 4, 9, 17, 17, 17, 20 };
	//Finds the first element greater than or equal to a given value
	vector<int>::iterator it = lower_bound(v.begin(), v.end(), 17);
	if (it != v.end()) {
		cout << "First element >= 17 " << *it << "\n";	// 17
		cout << "\tIndex: " << it - v.begin() << "\n";		// 6
	}
	//Finds the first element greater than a given value
	it = upper_bound(v.begin(), v.end(), 17);
	if (it != v.end())
		cout << "First element > 17 " << *it << "\n";	// 20

	it = upper_bound(v.begin(), v.end(), 20);
	if(it == v.end())
		cout<<"20 doesn't exist\n";

	auto p = equal_range(v.begin(), v.end(), 17);
	cout << p.first - v.begin() << " " << p.second - v.begin() << "\n";

	return 0;
}

/*
First element >= 17 17
	Index: 6
First element > 17 20
20 doesn't exist
6 9


 */

