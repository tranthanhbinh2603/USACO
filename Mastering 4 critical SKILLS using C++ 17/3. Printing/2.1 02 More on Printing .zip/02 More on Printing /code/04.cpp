#include<iostream>
using namespace std;

int main()
{
	cout<<1<<"\n";
	cout<<12<<"\n";
	cout<<123<<" is a number\n";
	cout<<"123"<<" is NOT a number\n";
	cout<<endl;

	cout<<15.7<<"\n";
	cout<<-12.52<<"\n";
	cout<<endl;

	cout<<1234<<"\n";
	cout<<4321<<"\n\n";

	cout<<43211234<<"\n";
	cout<<4321<<1234<<"\n";

	cout<<"\nMy luck number is: "<<17<<"\n";

	return 0;
}
