#include<iostream>
using namespace std;

int main()
{
	cout<<"I am Mostafa";
	return 0;

	cout<<endl;
	cout<<"I was born in Giza\n";
	cout<<"I graduated from Cairo university";
	cout<<endl;
}
