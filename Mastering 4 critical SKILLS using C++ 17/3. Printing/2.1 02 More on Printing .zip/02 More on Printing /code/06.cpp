#include<iostream>
using namespace std;

// Go over code line by line!

int main()
{
	cout<<"If your dream only includes you, it’s too small\n\n";

	cout<<30+20+10-10-20-30<<endl;
	cout<<"70/10"<<"\n";
	cout<<80/10/2<<"\n";

	cout<<"\nOpportunities don't happen. "
		<<"You create them"
		<<endl;

	// All progress takes place outside the comfort zone.

	/*
		Character cannot be developed in ease and quiet. Only through
			experience of trial and suffering can the soul be strengthened,
				ambition inspired, and success achieved
	 */

	return 0;

	cout<<"\n\nDo one thing every day that scares you";
}
