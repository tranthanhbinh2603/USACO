#include<iostream>
using namespace std;

int main()
{
	cout<<"I am Mostafa"
		<<endl<<"I was born in Giza"
		<<endl<<"I graduated from Cairo university"
		<<endl;

	return 0;
}
