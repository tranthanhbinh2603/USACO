#include<iostream>
using namespace std;

int main()
{
	cout<<"I am Mostafa";
	cout<<"I was born in Giza";
	cout<<"I graduated from Cairo university";

	return 0;
}
