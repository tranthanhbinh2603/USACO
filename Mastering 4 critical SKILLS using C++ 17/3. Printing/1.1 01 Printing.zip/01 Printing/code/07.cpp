#include<iostream>
using namespace std;

int main()
{
	cout<<"I am Mostafa\nI was born in Giza\nI graduated from Cairo university\n";

	return 0;
}
