#include<iostream>
using namespace std;

int main()
{
	cout<<"I am "<<"Mostafa"<<endl<<"I was born in Giza\n";
	cout<<"I graduated from Cairo university";
	cout<<endl;

	return 0;
}
