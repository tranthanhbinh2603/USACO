// Homework 1: Find all errors and fix them


#include<stream
using namespace STD


cout <<"work smart not hard\n";


int maIN() {


	cout << "Children must be taught how to think, not what to think\n"
	cout << "We worry about what a child will become "tomorrow", yet we forget that he is someone today\n";
	cout << "Children are not things to be molded"<", but are people to be unfolded\n";
	cout << "Each day of our lives we make deposits in the memory banks of our children."<<end;
	cout      << ""It is easier to build strong children than to repair broken men""<<"\n";
	cout >> "Children need models rather than critics\n";

	out<<"Children have never been very good at listening to their elders, but they have never failed to imitate them";

	cout < "Children are our most valuable resource\n";

