#include<iostream>
#include<vector>
using namespace std;

class Shape {
};

class TwoDimensionalShape : public Shape {
};

class Circle : public TwoDimensionalShape {
};

class Square : public TwoDimensionalShape {
};

class Triangle : public TwoDimensionalShape {
};




class ThreeDimensionalShape : public Shape {
};

class Sphere : public ThreeDimensionalShape {
};

class Cube : public ThreeDimensionalShape {
};

class Tetrahedron : public ThreeDimensionalShape {
};

int main() {


	return 0;
}
