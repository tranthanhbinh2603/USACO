#include<iostream>
using namespace std;

int main() {
	int age;
	cout<<"Enter age: ";
	cin>>age;

	double weight;
	cout<<"Enter weight: ";
	cin>>weight;

	char group;
	cout<<"Enter group: ";
	cin>>group;

	string name;
	cout<<"Enter name: ";
	cin>>name;

	cout<<"I am "<<name<<" belongs to group "<<group<<"\n";
	cout<<"My weight "<<weight<<" and age "<<age;

	return 0;
}
