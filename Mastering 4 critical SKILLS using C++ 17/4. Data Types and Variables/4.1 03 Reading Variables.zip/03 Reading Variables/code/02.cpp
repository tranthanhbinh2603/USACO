#include<iostream>
using namespace std;

int main() {
	int a, b;

	cout << "Enter 2 numbers\n";

	cin >> a >> b;

	cout << a * b << " " << a + b << "\n";

	return 0;
}
