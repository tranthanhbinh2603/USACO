#include<iostream>
using namespace std;

int main()
{
	int num;

	cout<<"Enter your lucky number\n";

	cin>>num;

	cout<<"********\n";
	cout<<2 * num + 1<<"\n";

	return 0;
}
