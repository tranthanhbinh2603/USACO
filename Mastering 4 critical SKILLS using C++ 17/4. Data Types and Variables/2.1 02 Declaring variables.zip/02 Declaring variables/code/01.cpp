#include<iostream>
using namespace std;

int main()
{
	// int for integer
	int age = 55;

	cout<<age<<"\n";

	// double used for fractions (or float)
	double weight = 92.5;

	cout<<"My weight is "<<weight<<"\n";

	return 0;
}
