#include <iostream>
#include <vector>
#include <assert.h>
#include <memory>	// smart pointers
using namespace std;

template<typename T>
void deleter(T *p) {
	cout<<"Let's force array deletion 1\n";
	delete p;
}

template<typename T>
struct array_deleter {
	void operator ()(T const * p) {
		cout<<"Let's force array deletion 2\n";
		delete[] p;
	}
};

void test() {
	shared_ptr<int> p1 { new int[16], deleter<int>};

	shared_ptr<int> p2 { new int[16], array_deleter<int>()};
}

int main() {
	test();

	return 0;
}
