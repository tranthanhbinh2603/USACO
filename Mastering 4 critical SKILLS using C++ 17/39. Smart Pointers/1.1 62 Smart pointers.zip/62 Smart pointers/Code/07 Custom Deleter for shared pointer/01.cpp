#include <iostream>
#include <vector>
#include <assert.h>
#include <memory>	// smart pointers
using namespace std;

void deleter(int *p) {
	cout << "Special delete\n";
	delete p;
}

void test() {
	shared_ptr<int> p1 { new int { 5 }, deleter };
}

int main() {
	test();

	return 0;
}
