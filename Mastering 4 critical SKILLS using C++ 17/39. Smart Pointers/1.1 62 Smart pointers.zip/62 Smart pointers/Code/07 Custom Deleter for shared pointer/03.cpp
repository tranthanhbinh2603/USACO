#include <iostream>
#include <vector>
#include <assert.h>
#include <memory>	// smart pointers
using namespace std;

void test() {
	unique_ptr<int> p1{new int[16]};	//ok

	// Ok since C++17 but not C++14
	//shared_ptr<int> p2{new int[16]};

	// The workaround was cusotomer deleter
	shared_ptr<int> p2{new int[16], [] (int* i) {
		cout<<"Let's force array deletion\n";
		delete[] i;}};
}

int main() {
	test();

	return 0;
}
