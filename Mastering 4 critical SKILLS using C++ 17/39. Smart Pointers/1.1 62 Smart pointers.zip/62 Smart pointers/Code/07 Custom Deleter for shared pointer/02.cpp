#include <iostream>
#include <vector>
#include <assert.h>
#include <memory>	// smart pointers
using namespace std;

struct LegacyDatabase {
	void release() {
	}
	~LegacyDatabase() {
	}
};

void old_way() {
	// Sadly badly designed legacy code
	LegacyDatabase *db = new LegacyDatabase();
	db->release();
	delete db;
}

void deleter(LegacyDatabase *db) {
	cout << "Special delete 1\n";
	db->release();
	delete db;
}

void test() {
	shared_ptr<LegacyDatabase> p1 { new LegacyDatabase(), deleter };

	shared_ptr<LegacyDatabase> p2 { new LegacyDatabase(),
		[](LegacyDatabase* db)
		{
			cout << "Special delete 2\n";
			db->release();
			delete db;
		}
	};
}

int main() {
	test();

	return 0;
}
