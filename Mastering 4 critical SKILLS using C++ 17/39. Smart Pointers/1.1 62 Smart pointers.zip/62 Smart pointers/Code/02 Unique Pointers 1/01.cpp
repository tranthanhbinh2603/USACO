#include <iostream>
#include <memory>	// smart pointers
using namespace std;

void test() {
	unique_ptr<int> p1 { new int { 20 } };	// Direct initialization

	// CE: conversion from int* to unique_ptr
	// Internally Explicit constructor
	//unique_ptr<int> p1 = new int { 20 };

	cout << *p1 << "\n";
	*p1 = 50;

	// CE: use of deleted operator=
	// p1 = new int {30};	 Similarly, can't just assign
	p1.reset(new int { 30 });	// delete old and use new
	cout << *p1 << "\n";

	// Once we go out of scope
	// p1 internals are destroyed
}

int main() {
	test();
	return 0;
}
