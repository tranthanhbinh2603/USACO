#include <iostream>
#include <memory>	// smart pointers
using namespace std;

void test() {
	unique_ptr<int> p1 { new int { 20 } };

	// CE: use of deleted Copy Constructor
	//unique_ptr<int> p2 {p1};

	// We can't use copy constructor
	// But we can move p1 internals to p2.
	// Useful for function calls in some scenarios
	unique_ptr<int> p2 { std::move(p1) };
	// Now: DON'T use p2 any more. Another pointer has ownership

	if (p1 == nullptr)
		cout<<"Yah\n";	// Yah

	// Force delete
	p2 = nullptr;	// Exception in assignment
	p2.reset();		// also set to nullptr
}

int main() {
	test();
	cout<<"bye\n";
	return 0;
}
