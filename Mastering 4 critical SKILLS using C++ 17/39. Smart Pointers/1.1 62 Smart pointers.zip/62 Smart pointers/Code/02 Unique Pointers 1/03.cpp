#include <iostream>
#include <memory>	// smart pointers
using namespace std;

void test() {
	unique_ptr<int> p { new int { 20 } };

	// p is an object: So it has its own address
	// Inside it is a raw pointer
		// The raw pointer itself: has an address
		// The raw pointer points to an address

	// Now we have 3 addresses!

	int *raw_p = p.get();	// . NOT ->

	// 20 0xfc20 0x7fff0 0x7fac
	cout << *raw_p << " " << raw_p << " " << &raw_p << " " << &p << "\n";
	// std::addressof(p) btw same as &p
}

int main() {
	test();
	cout << "bye\n";
	return 0;
}
