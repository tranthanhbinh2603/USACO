#include <iostream>
#include <memory>	// smart pointers
using namespace std;

void warnning() {
	int *p = new int { 30 };

	// You can assign same pointer to more than unique_ptr :(
	// Dangling pointer
	unique_ptr<int> p1 { p };
	unique_ptr<int> p2 { p };

	// RTE once we go out of the scoe
	// Tip: Don't assign raw pointers this way
}

int main() {
	warnning();
	cout<<"bye\n";
	return 0;
}
