#include <iostream>
#include <memory>	// smart pointers
using namespace std;

void print1(unique_ptr<int> p) {		// Pass by value
	if (p != nullptr)
		cout << *p << "\n";
}

void print2(unique_ptr<int> &p) {		// Pass by reference
	if (p != nullptr) {
		cout << *p << "\n";
		// They can destroy your pointer! Be careful
		p.reset();
	}
}
void print3(const unique_ptr<int> &p) {	// Pass by reference
	if (p != nullptr) {
		cout << *p << "\n";
		*p = 10;	// Value can be changed
		//unique_ptr<int> &p2 = p;
		//p.reset( new int { 7 } );
		// Good: no one can store or play with it
	}
}

void test() {
	unique_ptr<int> p1 { new int { 20 } };	// Direct initialization

	unique_ptr<int> &p2 = p1;	// Alias OK: still one owner

	//print1(p2);		// CE: use of deleted Copy Constructor
	print1(move(p2));	// Ok: Pass it, BUT don't use it after return

	p2.reset(new int { 30 });
	print2(p2);			// Perfect: Pass it, then you CAN use it after return
	//print2(move(p2));	// CE: temporary object to non const reference
	print3(move(p2));	// Ok now: const reference
}

int main() {
	test();
	cout << "bye\n";
	return 0;
}
