#include <iostream>
#include <memory>	// smart pointers
#include <assert.h>
using namespace std;

unique_ptr<int> get_instance() {
	unique_ptr<int> p { new int { 20 } };

	return p;
}

int main() {
	unique_ptr<int> x = get_instance();	// Moving object

	cout << "bye\n";

	return 0;
}
