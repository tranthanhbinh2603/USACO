#include <iostream>
#include <vector>
#include <memory>	// smart pointers
using namespace std;

struct Department;

struct Employee {
	shared_ptr<Department> department;
};
typedef shared_ptr<Employee> EmpPtr;
typedef vector<EmpPtr> empVec ;

struct Department {
	empVec employees;
};

int main() {
	EmpPtr e = make_shared<Employee>();
	shared_ptr<Department> d = make_shared<Department>();
	e->department = d;
	d->employees.push_back(e);

	// We are about to go out of scope
	// e waiting for d destruction to be released
	// d waiting for e destruction to be released
	cout<<e.use_count()<<" "<<d.use_count();	// 2 2
	return 0;
}
