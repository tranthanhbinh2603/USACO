#include <iostream>
#include <vector>
#include <assert.h>
#include <memory>	// smart pointers
using namespace std;

struct Department;

struct Employee {
	weak_ptr<Department> department;
	void print();	// you can't define. Incomplete.
};
struct Department {
	vector<shared_ptr<Employee>> employees;
};

shared_ptr<Department> d = make_shared<Department>();

void Employee::print() {
	if (!department.expired()) {
		d = nullptr;
		shared_ptr<Department> dep_orig = department.lock();
		if (dep_orig)
			cout << "Emp count " << dep_orig->employees.size() << "\n";
		else
			cout << "Tricky expire\n";
	} else
		cout << "expired\n";
}

int main() {
	shared_ptr<Employee> e = make_shared<Employee>();

	d->employees.push_back(e);
	e->department = d;
	e->print();

	return 0;
}
