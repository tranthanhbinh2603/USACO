#include <iostream>
#include <vector>
#include <memory>	// smart pointers
using namespace std;

struct Department;

struct Employee {
	weak_ptr<Department> department;
	~Employee()	{ cout<<"Destroy Emp\n"; }
};

struct Department {
	// Logic: Department is the actual OWNER
	vector<shared_ptr<Employee>> employees;
	~Department()	{ cout<<"Destroy Department\n"; }
};

int main() {

	shared_ptr<Employee> e = make_shared<Employee>();

	// 1) Create shared, 2) then assign/construct to weak ptr
	shared_ptr<Department> d = make_shared<Department>();
	e->department = d;	// Assign shared to weak
	//e->department = weak_ptr<Department>(d);	// Or

	d->employees.push_back(e);

	// weak from weak
	weak_ptr<Department> d2 = weak_ptr<Department>(e->department);
	return 0;
}
