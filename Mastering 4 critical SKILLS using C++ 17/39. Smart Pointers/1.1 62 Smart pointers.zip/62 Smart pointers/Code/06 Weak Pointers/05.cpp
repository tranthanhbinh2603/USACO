#include <iostream>
#include <vector>
#include <assert.h>
#include <memory>	// smart pointers
using namespace std;

struct Department;

struct Employee {
	weak_ptr<Department> department;
	void print();	// you can't define. Incomplete.
};
struct Department {
	vector<shared_ptr<Employee>> employees;
};

shared_ptr<Department> d = make_shared<Department>();

void Employee::print() {
	if (department.expired())
		return;	// e.g. remove from some processing queue
	if (auto dep_orig = department.lock())
		cout << "Emp count " << dep_orig->employees.size() << "\n";
}

int main() {
	shared_ptr<Employee> e = make_shared<Employee>();

	d->employees.push_back(e);
	e->department = d;
	e->print();

	return 0;
}
