#include <iostream>
#include <vector>
#include <memory>	// smart pointers
using namespace std;

void test() {
	typedef shared_ptr<int>  IntPtr;

	IntPtr p1 { new int { 20 } };

	cout<<p1.use_count()<<"\n";		// 1

	vector<IntPtr> vec;

	vec.push_back(p1);
	vec.push_back(p1);
	vec.push_back(p1);

	cout<<p1.use_count()<<"\n";		// 4

	vec.clear();

	cout<<p1.use_count()<<"\n";		// 1
}

int main() {
	test();
	return 0;
}
