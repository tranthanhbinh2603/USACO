#include <iostream>
#include <vector>
#include <memory>	// smart pointers
using namespace std;

struct Department;

struct Employee {
	shared_ptr<Department> department;
	~Employee()	{ cout<<"Destroy Emp\n"; }
};
typedef shared_ptr<Employee> EmpPtr;
typedef vector<EmpPtr> empVec ;

struct Department {
	empVec employees;
	~Department()	{ cout<<"Destroy Department\n"; }
};

int main() {
	EmpPtr e = make_shared<Employee>();
	shared_ptr<Department> d = make_shared<Department>();
	e->department = d;
	//d->employees.push_back(e);
	return 0;
}
