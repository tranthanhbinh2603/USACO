#include <iostream>
#include <memory>	// smart pointers
using namespace std;

void test() {
	shared_ptr<int> p1 { new int { 20 } };

	//shared_ptr<int> p1 = new int { 20 };	// CE
	// p1 = new int {30};					// CE

	shared_ptr<int> p2 { p1 };	// Copy constructor OK

	shared_ptr<int> p3;
	p3 = p2;					// Assignment ok
	*p1 = 5;

	// 5 5 5: SAME value
	cout << *p1 << " " << *p2 << " " << *p3 << "\n";

	auto p4 = make_shared<int>(20);		// preferred
}

int main() {
	test();
	return 0;
}
