#include <iostream>
#include <vector>
#include <memory>	// smart pointers
using namespace std;


void test() {
	vector<unique_ptr<int>> vec;

	vec.push_back(std::make_unique<int>(7));

	auto p1 = make_unique<int>(20);
	//vec.push_back(p1);  //CE Copy constructor
	vec.push_back(move(p1));	// ok: p1 now empty

	auto p2 = make_unique<int>(20);

	// emplace_back constructs in-place even without std::move
	vec.emplace_back(move(p2));
	vec.emplace_back(std::make_unique<int>(7));

	// Since C++17: You can use emplace_back with & return
	//auto &b = vec.emplace_back(std::make_unique<int>(7));

	for(auto &p : vec) {	// you must use &
	}
}

int main() {
	test();
	return 0;
}
