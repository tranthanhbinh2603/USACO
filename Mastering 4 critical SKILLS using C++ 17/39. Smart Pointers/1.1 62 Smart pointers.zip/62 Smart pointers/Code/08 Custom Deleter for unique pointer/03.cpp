#include <iostream>
#include <vector>
#include <assert.h>
#include <memory>	// smart pointers
using namespace std;

void deleter1(int *p) {
	cout << "Special delete\n";
	delete p;
}

typedef unique_ptr<int,function<void(int*)>> deleted_unique_ptr_int;

void test1() {
	unique_ptr<int, function<void(int*)> > p1 { new int { 5 }, deleter1 };

	deleted_unique_ptr_int p2(new int {5}, deleter1);
}

// Define global NOT local
// Generalization of typedef, allowing templates
template<typename T>
using deleted_unique_ptr = unique_ptr<T,function<void(T*)>>;

template<typename T>
void deleter2(T *p) {
	cout << "Special delete\n";
	delete p;
}

void test2() {
	deleted_unique_ptr<int>    p1(new int {5}     , deleter1);

	deleted_unique_ptr<double> p2(new double {5}, deleter2<double>);
}

int main() {
	test2();
	cout<<"bye\n";

	return 0;
}
