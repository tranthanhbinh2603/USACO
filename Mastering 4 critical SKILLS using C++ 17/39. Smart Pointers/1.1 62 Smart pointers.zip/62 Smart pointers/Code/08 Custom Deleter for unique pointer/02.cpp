#include <iostream>
#include <vector>
#include <assert.h>
#include <memory>	// smart pointers
using namespace std;

double f() {
	auto b = 1.5;	// double
	return b;
}

void test1() {
    double i = 10.2;
    double      j1 = i * 2;	// 20.4
    decltype(i) j2 = i * 2;	// j is double

    //  decltype(f()) = double
    decltype(f()) j3;
    j3 = 3;

	function< double() > f1 = f;
	decltype(&f) f2 = f;
	double t = f2();
}

void deleter(int *p) {
	cout << "Special delete\n";
	delete p;
}
void test2() {
	unique_ptr<int, decltype(&deleter) > p2 { new int { 5 }, deleter };
}

int main() {
	test2();
	cout<<"bye\n";

	return 0;
}
