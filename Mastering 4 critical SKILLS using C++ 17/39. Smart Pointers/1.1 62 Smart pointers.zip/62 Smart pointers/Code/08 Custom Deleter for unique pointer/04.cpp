#include <iostream>
#include <vector>
#include <assert.h>
#include <memory>	// smart pointers
using namespace std;

void deleter(int *p) {
	cout << "Special delete\n";
	delete p;
}
struct FunctorDeleter {
	void operator()(int* p) {	delete p;	}
};
void test2() {
	auto l = [](int* p) {delete p;};
	cout << sizeof(unique_ptr<int>) << "\n"; //default_delete = 	 8
	cout << sizeof(unique_ptr<int, FunctorDeleter>) << "\n"; 		//8
	cout << sizeof(unique_ptr<int, decltype(&deleter)>) << "\n"; 	//16
	cout << sizeof(unique_ptr<int, decltype(l)>) << "\n"; 			//8
	cout << sizeof(unique_ptr<int, void (*)(int*)>) << "\n"; //function pointer = 16
	cout << sizeof(unique_ptr<int, function<void(int*)>>) << "\n"; //40-64
}

int main() {
	test2();
	cout << "bye\n";

	return 0;
}
