#include <iostream>
#include <vector>
#include <assert.h>
#include <memory>	// smart pointers
using namespace std;

int sq(int x) {
	return x * x;
}
void test1() {
	// function that takes int and return int
	function< int(int) > f = sq;
	cout<<f(5)<<"\n";	// 25
}
void deleter(int *p) {
	cout << "Special delete\n";
	delete p;
}
void test2() {
	unique_ptr<int, function< void(int*) > > p2 { new int { 5 }, deleter };

	// function< void(int*) >
	// Expect a function
	// Return type: void
	// Parameter: int *
}

int main() {
	test2();

	return 0;
}
