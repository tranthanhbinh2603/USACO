#include<iostream>
using namespace std;

int main() {

	// Escape characters
	cout<<"hello\tworld\n";
	cout<<"\0";
	cout<<"Let's print a double quote \"  ";

	return 0;
}

