#include<iostream>
using namespace std;

int main() {

	// Array of names - each name is sequence of letters!
	string names[2];

	for (int i = 0; i < 2; ++i)
		cin>>names[i];

	return 0;
}

