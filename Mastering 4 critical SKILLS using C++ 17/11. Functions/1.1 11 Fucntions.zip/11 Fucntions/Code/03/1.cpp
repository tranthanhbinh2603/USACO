#include<iostream>
using namespace std;

int lucky_number() {
	return 13;
}

int main2() {
	return 0;
}

void print_sum(int a, int b) {
	cout << a + b << "\n";
}

int main() {
	cout << lucky_number() << "\n";
	print_sum(2, -5);

	return 0;
}

