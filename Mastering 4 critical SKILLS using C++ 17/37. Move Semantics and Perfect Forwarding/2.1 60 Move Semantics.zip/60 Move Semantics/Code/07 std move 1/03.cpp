#include <iostream>
using namespace std;

int &&OurMove(int &x) {
	return static_cast<int&&>(x);
}
void f2(int &a) {	cout << "f2() \n";	}
void f2(int &&a) {	cout << "f2&&() \n";}

void f1(int &a) {
	cout << "f1() \n";
	f2(a);
}
void f1(int &&a) {
	cout << "f1&&() \n";
	// Return of OurMove is interesting
	// It originally has identity (a)
	// It is now Rvalue Reference (can be moved)
	// This is called xvalue
		// Has identity and movable
	f2(OurMove(a));
}

int main() {
	f1(10);	// f1&&()    f2&&()



	return 0;
}

