#include <iostream>
using namespace std;

void f2(int &a) {	cout << "f2() \n";	}
void f2(int &&a) {	cout << "f2&&() \n";}

void f1(int &a) {
	cout << "f1() \n";
	f2(a);
}
void f1(int &&a) {
	cout << "f1&&() \n";
	f2(static_cast<int&&>(a));
}

int main() {
	int x = 10;
	// By casting x to int&&, we force it be Rvalue reference
	// That we convert an Lvalue to Rvalue Reference!
	int &&xr= static_cast<int&&>(x);

	f1(10);	// f1&&()    f2&&()

	// xr is a name
	// name ==> lvalue
	// Don't fotget :)
	f1(xr);	// f1() f2()



	return 0;
}

