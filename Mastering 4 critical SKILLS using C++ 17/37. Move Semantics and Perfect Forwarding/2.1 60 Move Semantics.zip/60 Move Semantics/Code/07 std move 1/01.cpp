#include <iostream>
using namespace std;

void f2(int &a) {	cout << "f2() \n";	}
void f2(int &&a) {	cout << "f2&&() \n";}

void f1(int &a) {
	cout << "f1() \n";
	f2(a);
}
void f1(int &&a) {
	cout << "f1&&() \n";
	// a is LVALUE, will match f2() NOT f2&&()
	f2(a);
}

int main() {
	f1(10);	// f1&&()    f2()

	// we want f2&&() be called
	// Think in simple trick?

	return 0;
}

