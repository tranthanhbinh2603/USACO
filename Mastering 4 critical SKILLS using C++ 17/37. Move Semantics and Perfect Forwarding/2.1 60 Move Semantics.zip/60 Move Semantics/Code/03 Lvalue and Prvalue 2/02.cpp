#include <iostream>
#include <cmath>
using namespace std;

struct Employee {
	int salary = 10;	// salary is lvalue

	// Return by value 			=> prvalue
	int get1()  {		return salary;	}
	// Return by reference 		=> lvalue reference
	int& get2() {		return salary;	}
};

int main() {
	Employee e;

	int s1 = e.get1();

	//CE: lvalue required as left operand of assignment
	//e.get1() = 50;

	// get2 return identifiable address (lvalue)
	int s2 = e.get2();
	int &s3 = e.get2();
	s3 = 70;	// now salary = 70
	e.get2() = 50;			// int &salary = 50;

	// max reurn "const lvalue reference" NOT prvalue  [in gcc]
	const int &r = max(2, 3);

	// in std: getline(cin, str), cout << 1, str1 = str2, or ++it
	// all return by reference => lvalue


	return 0;
}

