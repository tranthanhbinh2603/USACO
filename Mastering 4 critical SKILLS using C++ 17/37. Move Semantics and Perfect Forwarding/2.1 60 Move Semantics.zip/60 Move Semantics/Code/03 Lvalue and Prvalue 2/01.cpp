#include <iostream>
#include <cmath>
using namespace std;


void f1(int a) {}
void f2(int &a) {}
void f3(const int &a) {}

int main() {
	int x = 1;
	const int y = 2;

	f1(10);
	f1(x);
	f1(y);

	// f2(10) same as: int &a = 10;
		// a  => non-const lvalue reference 
		// 10 => prvalue
	//f2(10);	CE: cannot bind non-const lvalue reference to prvalue
	f2(x);
	//f2(y);	CE: y is const but int &a not

	// f3 takes lvalue, prvalue, const lvalue
	f3(10);
	f3(x);
	f3(y);



	return 0;
}

