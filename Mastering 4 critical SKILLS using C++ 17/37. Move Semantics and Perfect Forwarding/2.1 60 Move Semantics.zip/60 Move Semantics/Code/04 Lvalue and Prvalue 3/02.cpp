#include <iostream>
#include <cmath>
using namespace std;


int main() {
	// Array names are non-modifiable lvalues
	int arr[] {1, 2, 3, 4};
	//arr = &x;		CE non-modifiable
	int* p = arr;	// points to lvalue
	//p + 1 = arr;	// CE: p + 1 is an prvalue
	*(p + 1) = 10;   // *(p + 1) is an lvalue

	// * operator converts prvalue to lvalue
	// & operator converts lvalue to prvalue

	int a = 10;
	p = &a;           	// a is lvalue and &a is prvalue
	//p = &(a+1);       // CE: a+1 is prvalue
	//&a = 40;          // &a is not lvalue

	//int *p2 = 10;	CE 10 is prvalue
	// the only literal exception is c string literals, as they are arrays
	char* char_ptr = "mostafa";

	//string &ref2 = "mostafa";
	// CE: cannot bind non-const lvalue reference to an prvalue
		// ref2 is non-const lvalue reference
		// "mostafa" is prvalue

	// We can assign lvalue/prvalue to a const lvalue reference
	const string &ref2 = "mostafa";


	return 0;
}

