#include<iostream>
#include<utility>
#include<vector>
using namespace std;

class MyPair {
private:
	int *firstPtr = nullptr;
	int *secondPtr = nullptr;
public:
	MyPair(int first = 0, int second = 0) {
		cout<<"Constructor\n";
		SetFirst(first), SetSecond(second);
	}

	MyPair(const MyPair& other) {
		cout<<"Copy Constructor\n";
		SetFirst(*other.firstPtr);
		SetSecond(*other.secondPtr);
	}
	MyPair(MyPair&& other) {
		cout<<"Move Constructor\n";
		// 1) copy pointer addresses
		firstPtr = other.firstPtr;
		secondPtr = other.secondPtr;
		// 2) Null other
		other.firstPtr = other.secondPtr = nullptr;
	}
	~MyPair() {
		cout<<"~MyPair()\n";

		if (firstPtr == nullptr && secondPtr == nullptr)
			cout<<"\tFreed already by a move!\n";

		if (firstPtr != nullptr)
			delete firstPtr;

		if (secondPtr != nullptr)
			delete secondPtr;
	}
	void SetFirst(int first) {
		if (firstPtr == nullptr)
			firstPtr = new int;
		*firstPtr = first;
	}

	void print() {
		cout << "(" << *firstPtr << "," << *secondPtr << ")\n";
	}
	int GetFirst() const {
		return *firstPtr;
	}

	int GetSecond() const {
		return *secondPtr;
	}
	void SetSecond(int second) {
		if (secondPtr == nullptr)
			secondPtr = new int;
		*secondPtr = second;
	}

};

int main() {
	vector<MyPair> v;

	v.push_back(MyPair(3, 6));	// rvalue
	// Constructor for temp MyPair(3, 6)
		// Create 2 integers
	// Move Constructor
		// No creation/copying
	// ~MyPair()
		// Freed already by a move!
	// ~MyPair()
		// Delete 2 integers

	MyPair p1(1, 5);
	MyPair p2(p1);	// lvalue -> copy constructor


	return 0;
}
