#include<iostream>
#include<utility>
#include<vector>

using namespace std;

void g(int &x) {
	cout << "f(int)\n";
	x = 10;
}

template<typename T>
void f(T && a) {
	// CE: g(rvalue) going to reference lvalue
	g(forward<T>(a));
}
// only 1 generated
void f_gen(int &&a) {	g(move(a) );	}

int main() {
	f(17);
}
