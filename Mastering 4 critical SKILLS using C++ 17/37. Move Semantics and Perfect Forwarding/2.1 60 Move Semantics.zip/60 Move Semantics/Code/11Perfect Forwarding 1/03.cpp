#include<iostream>
#include<utility>
#include<vector>

using namespace std;

void g(const int& x) {
	cout << "f(const int&)\n";
	//x = 5;	// const
}
void g(int& x) {
	cout << "f(int&)\n";
	x = 10;		// caller affected
}
void g(int&& x) {
	cout << "f(int&&)\n";
	x = 20; 	// caller affected
}
template<typename T>
void f(T && a) {
	//g(a);		// all calls will be int&
	//internally: g(  static_cast<T&&>(a)   );
	g(forward<T>(a));
}

int main() {
	int val = 2;
	int &valr = val;
	const int CC = 3;
	int &&r1 = 10;
	int &r2 = r1;	// & && [reference to rvalue reference)

	// Lvalue cases (have name)
	f(CC);			// T = const int &		=> f(const int&)
	f(val);			// T = int &			=> f(int&)
	f(valr);		// T = int &			=> f(int&)
	f(r1);			// T = int &			=> f(int&) : [r1 is lvalue]
	f(r2);			// T = int &			=> f(int&) : [r2 is lvalue]

	cout<<val<<" "<<valr<<" "<<r1<<"\n";	// 10 10 10

	// Rvalue cases (prvalue or xvalue) (no or hided name)
	f(17);			// T = int&&	=> f(int&&)	: prvalue
	f(move(r1));	// T = int&&	=> f(int&&)	: xvalues
	f(move(val));	// T = int&&	=> f(int&&)	: xvalues

	cout<<val<<" "<<valr<<" "<<r1<<"\n";	// 20 20 20
}
