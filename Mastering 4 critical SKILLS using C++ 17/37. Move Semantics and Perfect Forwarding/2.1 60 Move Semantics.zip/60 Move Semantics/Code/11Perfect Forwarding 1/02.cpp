#include<iostream>
#include<utility>
#include<vector>

using namespace std;

// Template + && => Reference forwarding function
// Forwarding references allow a reference to bind to
	// either an lvalue or rvalue depending on the type
template<typename T>
void f(T && a) {}

// Assume T is int
// Based on arguments, compiler GENERATES these functions
void f_gen(const int &a) 	{}
void f_gen(int &a) 			{}
void f_gen(int &&a) 		{}

int main() {
	int val = 2;
	const int CCC = 3;

	// For Lvalue type => bind to lvalue reference
	f(CCC);	// use void f_gen(const int &a)
	f(val);	// use void f_gen(int &a)

	// For Rvalue type => bind to rvalue reference
	f(100);	// use void f_gen(int &&a)

}
