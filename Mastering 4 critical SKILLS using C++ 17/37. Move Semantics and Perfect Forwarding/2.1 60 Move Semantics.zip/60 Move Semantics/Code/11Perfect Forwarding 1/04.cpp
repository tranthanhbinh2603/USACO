#include<iostream>
#include<utility>
#include<vector>

using namespace std;

void g(int x) {
	cout << "f(int)\n";
	x = 10;
}

template<typename T>
void f(T && a) {
	g(forward<T>(a));
}

// only 2 generated
void f_gen(int &a) 	{
	g(a);
}
void f_gen(int &&a) {
	g(move(a));
}

int main() {
	int val = 2;

	f(val);	// T = int&		=> f(int&)
	f(17);	// T = int&&	=> f(int&&)

	cout<<val<<"\n";	// 2
}
