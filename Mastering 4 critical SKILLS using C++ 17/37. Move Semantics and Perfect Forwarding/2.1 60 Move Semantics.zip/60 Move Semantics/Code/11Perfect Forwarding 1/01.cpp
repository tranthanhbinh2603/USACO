#include<iostream>
#include<utility>
#include<vector>

using namespace std;

class Student {
private:
	string full_name, nick_name, address;
public:
	// How many constructors if supporting Rvalue Ref or const Lvalue reference PER parameter?
	// 2x2x2 = 8 ==> exponential counting! Very impractical
	Student(string &&full_name, string &&nick_name, string &&address) 				{ cout<<"RRR\n"; }
	Student(string &&full_name, string &&nick_name, const string &address) 			{ cout<<"RRL\n"; }
	Student(string &&full_name, const string &nick_name, string &&address) 			{ cout<<"RLR\n"; }
	Student(string &&full_name, const string &nick_name, const string &address) 	{ cout<<"RLL\n"; }
	Student(const string &full_name, string &&nick_name, string &&address) 			{ cout<<"LRR\n"; }
	Student(const string &full_name, string &&nick_name, const string &address) 	{ cout<<"LRL\n"; }
	Student(const string &full_name, const string &nick_name, string &&address) 	{ cout<<"LLR\n"; }
	Student(const string &full_name, const string &nick_name, const string &address){ cout<<"LLL\n"; }
};
int main() {
   string L;
   Student("", "", "");	// RRR
   Student("", L, "");	// RLR

   return 0;
}
