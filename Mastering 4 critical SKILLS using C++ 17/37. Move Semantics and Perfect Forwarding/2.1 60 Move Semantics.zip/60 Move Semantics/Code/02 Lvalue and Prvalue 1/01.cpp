#include <iostream>
using namespace std;


int main() {
	int salary = 100;
	// Salary is lvalue and 100 is prvalue

	// Salary: has some identifiable address
	// we can change it (unless const used)
	// EVERY variable name is lvalue

	// 100: literate - a TEMPORARY value
	// No name / No identifiable address
	// Not assignable

	// Normal. Go to addressof(sal2) set value 200
	salary = 200;

	// CE: lvalue required as left operand of assignment
	// It means 200 is not lvalue: no identifiable address to put salary
	//200 = salary;		// Not assignable

	return 0;
}

