#include <iostream>
#include <cmath>
#include <vector>
using namespace std;


int main() {
	int a = 3, b = 2, c = 2 * a + b;
	const double D = sqrt(25.0);
	string lang = "cpp";

	// 3, 2, 2*a+b, "cpp", sqrt(25) => prvalues
	// a, b, c, D, lang             => lvalue

	// referencing an lvalue
	int &ref1 = b;	// lvalue reference (non-const)
	ref1 = 20;		// ok, ref1 is addressable
	//ref1+1 = 4;	// CE ref1+1 is a prvalue = temporary

	const int &ref2 = b;	// lvalue reference (const)
	//ref2 = 20;			// CE const lvalue

	// operator + needs prvalues
	c = a + b;	// a and b are converted to prvalues implicitly
	// Most operators expect prvalues as their operands
	// Assignment operator requires an lvalue (lvalue = expr)

	// No name = temporary = prvalue
	vector<int>(10);	// prvalue
	double {};			// prvalue



	return 0;
}

