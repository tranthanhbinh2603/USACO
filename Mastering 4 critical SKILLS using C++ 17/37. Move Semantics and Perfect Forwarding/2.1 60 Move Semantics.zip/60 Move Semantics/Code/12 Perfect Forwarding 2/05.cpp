#include<iostream>
#include<vector>
#include<utility>
using namespace std;


int main() {

	vector< pair<int, string> > v;
	v.push_back( make_pair(2, "mostafa") );
	// Header: Perfect Forwarding for vardic template + forward
	v.emplace(v.end(), 3, "ziad");



	return 0;
}
