#include<iostream>
#include<utility>
#include<vector>

using namespace std;

class Student {
private:
	string full_name, nick_name, address;
public:
	Student(string full_name, string nick_name, string address)  :
		full_name(std::move(full_name)),
		nick_name(std::move(nick_name)),
		address(std::move(address))
	{
	}
};

int main() {

   string L = "hello";
   Student("x", L, "y");

   return 0;
}

