#include<iostream>
#include<utility>
#include<vector>

using namespace std;

class Student {
private:
	string full_name, nick_name, address;
public:
	// Use one for each param, not same T
	template<typename T1, typename T2, typename T3>
	Student(T1 &&full_name, T2 &&nick_name, T3 &&address)  :
		full_name(std::forward<T1>(full_name)),
		nick_name(std::forward<T2>(nick_name)),
		address(std::forward<T3>(address))
	{
	}
};

int main() {
   string L;
   Student("", "", "");	// RRR
   Student("", L, "");	// RLR

   return 0;
}

