#include<iostream>
#include<vector>
#include<utility>
using namespace std;

template<typename T, typename ... Args>
// Perfect Forwarding for vardic template
T create(Args&& ... args) {
	// cast then ...
	return T(forward<Args>(args)...);
}

int main() {
	int val = create<int>(7);
	double doub = create<double>();	// 0

	string s { "mostafa" };
	cout << create<string>(s) << " " << create<string>("mostafa") << "\n";

	vector<int> v1 = move(create<vector<int> >(5, 1000));
	cout << v1.size() << " " << v1[0] << "\n";	// 5 1000

	typedef vector<int> vec1d;
	typedef vector<vec1d> vec2d;
	vec2d v2 = move(create<vec2d>(7, create<vec1d>(3, 153)));
}
