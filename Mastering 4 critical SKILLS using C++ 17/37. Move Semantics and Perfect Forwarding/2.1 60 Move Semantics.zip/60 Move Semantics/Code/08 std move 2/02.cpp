#include<iostream>
#include<utility>
#include<vector>
using namespace std;

class Employee {
public:
	Employee() = default;
	Employee(const Employee& emp) { cout << "Copy\n"; }
	Employee(Employee&& emp) 	  { cout << "Move\n"; }
};
class Department {
private:
	Employee e;
public:
	Department(Employee &&etemp) : e(move(etemp)) {}
	Department(Employee &etemp)  : e(etemp) {}
};
int main() {
	Employee e1;
	Department d1(e1);			// copy
	Department d2( Employee{} );// move

	return 0;
}
