#include<iostream>
#include<utility>
#include<vector>
using namespace std;

string global = "hello";
string&& Get() {
	return move(global);	// No RTE
}
// We better use const lvalue reference
// Below For educational purpose
string&& min_str1(string&& a, string &&b) {
	if (a < b)
		return move(a);
		//return a;	// CE lvaue
	return move(b);
	// Rvaluae reference to an argument here is ok to return
	// No objects to be destroyed
}
string&& min_str2(string a, string b) {
	if (a < b)
		return move(a);
	return move(b);	// WRONG: a/b temp and will be destroyed
	// Never use std::move to move automatic objects out of functions.
}
int main() {
   string &&s = min_str1(string("Mostafa"), std::string("Ziad"));

   return 0;
}
