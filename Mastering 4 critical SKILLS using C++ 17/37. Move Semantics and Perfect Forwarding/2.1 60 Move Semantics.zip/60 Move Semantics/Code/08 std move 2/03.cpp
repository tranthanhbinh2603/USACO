#include<iostream>
#include<utility>
#include<vector>
using namespace std;

// Supports copy & move semantics
class MyPair {
private:
	int *firstPtr = nullptr;
	int *secondPtr = nullptr;
public:
	MyPair(int first = 0, int second = 0) {
		cout << "Constructor\n";
		SetFirst(first), SetSecond(second);
	}

	MyPair(const MyPair& other) {
		cout << "Copy Constructor\n";
		SetFirst(*other.firstPtr);
		SetSecond(*other.secondPtr);
	}
	MyPair(MyPair&& other) {
		cout << "Move Constructor\n";
		// 1) copy pointer addresses
		firstPtr = other.firstPtr;
		secondPtr = other.secondPtr;
		// 2) Null other
		other.firstPtr = other.secondPtr = nullptr;
	}

	MyPair& operator=(MyPair& other) {
		cout << "Assignment lvalue\n";
		if (this == &other)
			return *this;

		if (other.firstPtr != nullptr)
			SetFirst(*other.firstPtr);

		if (other.secondPtr != nullptr)
			SetSecond(*other.secondPtr);

		return *this;
	}
	MyPair& operator=(MyPair&& other) {
		cout << "Assignment rvalue\n";
		if (this == &other)
			return *this;

		// Free mine
		if (firstPtr != nullptr)
			delete firstPtr;

		if (secondPtr != nullptr)
			delete secondPtr;

		// 1) copy pointer addresses
		firstPtr = other.firstPtr;
		secondPtr = other.secondPtr;
		// 2) Null other
		other.firstPtr = other.secondPtr = nullptr;

		return *this;
	}

	~MyPair() {
		cout << "~MyPair()\n";

		if (firstPtr == nullptr && secondPtr == nullptr)
			cout << "\tFreed already by a move!\n";

		if (firstPtr != nullptr)
			delete firstPtr;

		if (secondPtr != nullptr)
			delete secondPtr;
	}
	void SetFirst(int first) {
		if (firstPtr == nullptr)
			firstPtr = new int;
		*firstPtr = first;
	}

	void print() {
		cout << "("  << *firstPtr << "," << *secondPtr << ")\n";
	}
	int GetFirst() const {
		return *firstPtr;
	}

	int GetSecond() const {
		return *secondPtr;
	}
	void SetSecond(int second) {
		if (secondPtr == nullptr)	secondPtr = new int;
		*secondPtr = second;
	}
};
int main() {
	vector<MyPair> v;
	MyPair p1(2, 5);
	MyPair &&pr = std::move(p1);	// like ours, but generic

	v.push_back(pr);			// lvalue :)
	v.push_back(std::move(p1));	// rvalue ref

	v.back().print();
	//p1.print();		// RTE: pointers are null now

	// Let's reuse. Our set functions create new memo if needed
	p1.SetFirst(10);
	p1.SetSecond(20);
	p1.print();

	return 0;
}
