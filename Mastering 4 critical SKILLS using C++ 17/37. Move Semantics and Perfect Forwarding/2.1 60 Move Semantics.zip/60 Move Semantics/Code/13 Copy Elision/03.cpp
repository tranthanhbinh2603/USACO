#include<iostream>
#include<utility>
#include<vector>
using namespace std;

class Employee {
public:
	Employee() = default;
	Employee(const Employee& emp) = delete;
	Employee(Employee&& emp) = delete;
};

Employee Get1() {
	return Employee {};
	// Later see return of unique pointer
}

int main() {
	Employee e = Get1();

	return 0;
}
