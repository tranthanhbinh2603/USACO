#include<iostream>
#include<utility>
#include<vector>
using namespace std;

// Supports copy & move semantics
class MyPair {
private:
	int *firstPtr = nullptr;
	int *secondPtr = nullptr;
public:
	MyPair(int first = 0, int second = 0) {
		cout << "Constructor\n";
		SetFirst(first), SetSecond(second);
	}

	MyPair(const MyPair& other) {
		cout << "Copy Constructor\n";
		SetFirst(*other.firstPtr);
		SetSecond(*other.secondPtr);
	}
	MyPair(MyPair&& other) {
		cout << "Move Constructor\n";
		// 1) copy pointer addresses
		firstPtr = other.firstPtr;
		secondPtr = other.secondPtr;
		// 2) Null other
		other.firstPtr = other.secondPtr = nullptr;
	}

	MyPair& operator=(MyPair& other) {
		cout << "Assignment lvalue\n";
		if (this == &other)
			return *this;

		if (other.firstPtr != nullptr)
			SetFirst(*other.firstPtr);

		if (other.secondPtr != nullptr)
			SetSecond(*other.secondPtr);

		return *this;
	}
	MyPair& operator=(MyPair&& other) {
		cout << "Assignment rvalue\n";
		if (this == &other)
			return *this;

		// Free mine
		if (firstPtr != nullptr)
			delete firstPtr;

		if (secondPtr != nullptr)
			delete secondPtr;

		// 1) copy pointer addresses
		firstPtr = other.firstPtr;
		secondPtr = other.secondPtr;
		// 2) Null other
		other.firstPtr = other.secondPtr = nullptr;

		return *this;
	}

	~MyPair() {
		cout << "~MyPair()\n";

		if (firstPtr == nullptr && secondPtr == nullptr)
			cout << "\tFreed already by a move!\n";

		if (firstPtr != nullptr)
			delete firstPtr;

		if (secondPtr != nullptr)
			delete secondPtr;
	}
	void SetFirst(int first) {
		if (firstPtr == nullptr)
			firstPtr = new int;
		*firstPtr = first;
	}

	void print() {
		cout << "("  << *firstPtr << "," << *secondPtr << ")\n";
	}
	int GetFirst() const {
		return *firstPtr;
	}

	int GetSecond() const {
		return *secondPtr;
	}
	void SetSecond(int second) {
		if (secondPtr == nullptr)	secondPtr = new int;
		*secondPtr = second;
	}
};

class Manager {
private:
	MyPair p = MyPair(10, 20);
public:
	MyPair Get1() {			// In C++17
		return MyPair(3, 6);// Definitely performs copy elision
	}

	MyPair Get2() {
		MyPair p1(2, 5);	// Constructor
		return p1;			// Maybe performs copy elision
	}
	MyPair Get3() {
		return p;			// must invoke Copy Constructor
	}
};

int main() {
	Manager mgr;
	MyPair p1 = mgr.Get2();
	// No call for copy or move constructor!
	// ~MyPair()

	return 0;
}
