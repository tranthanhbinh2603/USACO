#include<iostream>
#include<utility>
#include<vector>
using namespace std;

// Supports copy & move semantics
class MyPair {
private:
	int *firstPtr = nullptr;
	int *secondPtr = nullptr;
public:
	MyPair(int first = 0, int second = 0) {
		cout << "Constructor\n";
		SetFirst(first), SetSecond(second);
	}

	MyPair(const MyPair& other) {
		cout << "Copy Constructor\n";
		SetFirst(*other.firstPtr);
		SetSecond(*other.secondPtr);
	}
	MyPair(MyPair&& other) {
		cout << "Move Constructor\n";
		// 1) copy pointer addresses
		firstPtr = other.firstPtr;
		secondPtr = other.secondPtr;
		// 2) Null other
		other.firstPtr = other.secondPtr = nullptr;
	}

	MyPair& operator=(MyPair& other) {
		cout << "Assignment lvalue\n";
		if (this == &other)
			return *this;

		if (other.firstPtr != nullptr)
			SetFirst(*other.firstPtr);

		if (other.secondPtr != nullptr)
			SetSecond(*other.secondPtr);

		return *this;
	}
	MyPair& operator=(MyPair&& other) {
		cout << "Assignment rvalue\n";
		if (this == &other)
			return *this;

		// Free mine
		if (firstPtr != nullptr)
			delete firstPtr;

		if (secondPtr != nullptr)
			delete secondPtr;

		// 1) copy pointer addresses
		firstPtr = other.firstPtr;
		secondPtr = other.secondPtr;
		// 2) Null other
		other.firstPtr = other.secondPtr = nullptr;

		return *this;
	}

	~MyPair() {
		cout << "~MyPair()\n";

		if (firstPtr == nullptr && secondPtr == nullptr)
			cout << "\tFreed already by a move!\n";

		if (firstPtr != nullptr)
			delete firstPtr;

		if (secondPtr != nullptr)
			delete secondPtr;
	}
	void SetFirst(int first) {
		if (firstPtr == nullptr)
			firstPtr = new int;
		*firstPtr = first;
	}

	void print() const {
		cout << "("  << *firstPtr << "," << *secondPtr << ")\n";
	}
	int GetFirst() const {
		return *firstPtr;
	}

	int GetSecond() const {
		return *secondPtr;
	}
	void SetSecond(int second) {
		if (secondPtr == nullptr)	secondPtr = new int;
		*secondPtr = second;
	}
};
class Manager {
private:
	MyPair p = MyPair(10, 20);
public:

	MyPair Get1() {			// In C++17
		// Return Value Optimization
		return MyPair(3, 6);	// Definitely performs copy elision
	}
	MyPair Get2() {
		// Named Return Value Optimization (NRVO)
		MyPair p1(2, 5);
		return p1;				// Maybe performs copy elision
	}

	MyPair Get3() {
		return p;			// must invoke Copy/Move Constructor
	}

	void Recieve1(const MyPair &pp) {
		p = MyPair(pp);		// Copy Constructor + Assignment
	}
	void Recieve2(MyPair pp) {
		p = move(pp);		// Assignment
	}
};
int main() {
	Manager mgr;
	const MyPair p = MyPair(2, 7);

	mgr.Recieve2(p);				// No call Copy Constructor
	mgr.Recieve1(MyPair(2, 7));		// No call Copy Constructor

	mgr.Recieve2(p);				// Must call Copy Constructor
	mgr.Recieve2(MyPair(2, 7));		// No call Copy Constructor ***
									// Copy elision
									// Great even without move/copy Constructor





	return 0;
}
