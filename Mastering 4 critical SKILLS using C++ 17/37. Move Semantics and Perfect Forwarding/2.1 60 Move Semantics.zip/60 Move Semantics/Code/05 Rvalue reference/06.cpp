#include <iostream>
#include <cmath>
using namespace std;

int global = 20;

int prvalue() {
	return 10;
}
int& lvalue1() {
	return global;
}
int& lvalue2() {
	int local = 20;
	return local;	// WRONG. temp value will be destroyed
}
int&& xvalue() {
	int t = 10;
	//return t;		// CE: bind rvaule to lvalue: int &&r = t;
	//return &t;	// CE invalid conversion from int* to int
	return 10;		// WRONG. temp value will be destroyed
	// rvalue reference is JUST a reference.
	// It points to something that might be destroyed
}
int main() {
	int x1 = prvalue();
	//int &x2 = prvalue();		//CE  bind lvalue to rvalue
	int&& x3 = prvalue();

	int y1 = lvalue1();
	int &y2 = lvalue1();
	//int&& y3 = lvalue();		//CE: bind rvalue to lvalue

	//int z1 = xvalue();	// Potential RTE
	//int &z2 = xvalue();	//CE  bind lvalue to rvalue
	//int&& y3 = xvalue();	// Potential RTE

	cout << x3;

	cout << "\nbye\n";

	return 0;
}

