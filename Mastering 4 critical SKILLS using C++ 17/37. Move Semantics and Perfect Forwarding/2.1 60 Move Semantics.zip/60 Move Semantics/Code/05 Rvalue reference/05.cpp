#include <iostream>
#include <cmath>
using namespace std;

void f2(int &a) {	cout << "f2() \n";	}
void f2(int &&a) {	cout << "f2&&() \n";}

void f1(int &a) {
	cout << "f1() \n";
	f2(a);
}
void f1(int &&a) {
	cout << "f1&&() \n";
	// a is LVALUE, will match f2() NOT f2&&()
	f2(a);
}
int main() {
	int x = 10;
	int &&xr = 20;

	f2(x);	// f2()
	f2(10);	// f2&&()
	f1(x);	// f1() f2()

	f1(10);	// f1&&()    f2()
	// First call matches f1&&()
	// The tricky part, the call from f1&&()
		// a value category is LVALUE
		// So it matches f2()

	// But this is a big performance concern
	// We wanted f2 also called by rvalue reference
		// To avoid the extra copies!

	f2(xr);	// f2()  : xr is LVALUE

	return 0;
}

