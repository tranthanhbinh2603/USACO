#include<iostream>
#include<utility>
#include<cmath>
using namespace std;

int main() {
	// lvalue reference (binds only to lvalue)
	int a = 10;
	int &lvalue_ref = a;

	int t    = 2 * a + 1;
	// Create some temp in memory
	// Put value 2*a+1 in it
		// *** Copy the temp to addressof t

	// since c++11: rvalue reference: Reference to temporary objects
	// && (double ampersand): rvalue reference operator

	int &&r1 = 2 * a + 1;	// 2*a+1 is temporary expression = prvalue
	// Create some temp in memory
	// Put value 2*a+1 in it
		// *** Put the temp ADDRESS in r1
		// no EXTRA copy => A LOT OF performance GAIN for heavy objects
	// Logic: temp will be gone soon, why not making use of it

	//CE: rvalue reference (binds only to rvalues)
	//int &&r2 = a;

	return 0;
}
