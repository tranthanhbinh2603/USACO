#include <iostream>
#include <cmath>
using namespace std;

// function overloading
void f1(int &a) 		{cout<<"f1(int &a) \n";}
void f1(const int &a) 	{cout<<"f1(const int &a) \n";}
void f2(int &a) 		{cout<<"f2(int &a) \n";}
void f2(const int &a) 	{cout<<"f2(const int &a) \n";}
void f2(int &&a) 		{cout<<"f2(int &&a)\n";}
int main() {
	int x = 1;			// lvalue
	int &y = x;			// lvaue reference
	const int z = 2;	// const lvalue

	f1(x);		// f1(int &a)
	f1(y);		// f1f1(int &a)
	f1(z);		// f1(const int &a)
	f1(10);		// f1(const int &a)

	f2(x);		// f2(int &a)
	f2(y);		// f2(int &a)
	f2(z);		// f2(const int &a)
	f2(10);		// ff2(int &&a) *****
	// prvalue first priority matching is rvalue reference
	// why? It can avoids us extra copies!

	return 0;
}

