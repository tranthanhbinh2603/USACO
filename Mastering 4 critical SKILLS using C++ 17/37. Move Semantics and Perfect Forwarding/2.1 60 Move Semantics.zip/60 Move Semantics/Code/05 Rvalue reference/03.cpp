#include<iostream>
#include<utility>
#include<cmath>
using namespace std;

int main() {
	int &&r1 = 10;

	// 21 0x7fff41e81d00 4
	cout << r1 << " " << &r1 << " " << sizeof(r1) << "\n";

	int *p = &r1;	// r1 is an lvalue here

	// variable type != value category
	// r1 variable type = rvalue reference &&
	// the NAME of a variable is lvalue, regardless of type
		// As it has identifiable address &r1
	// value_category is BASED on a property of the EXPRESSION

	// Every expression has a type, and belongs to a value category
		// 2 independent properties
	// Value category is a classification of expression not a value

	int x = 1;
	int &y = x;	// type: lvalue reference. y value category = lvalue






	return 0;
}
