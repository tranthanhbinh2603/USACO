#include <iostream>
#include <cmath>
using namespace std;


void f1(int a) 			{cout<<"f1\n";}
void f2(int &a) 		{cout<<"f2\n";}
void f3(const int &a) 	{cout<<"f3\n";}
void f4(int &&a) 		{cout<<"f4\n";}
int main() {
	int x = 1;			// lvalue
	const int y = 2;	// const lvalue
	int &z = x;			// lvalue reference
	int &&w = 10;		// rvalue reference

	f1(x), f1(y), f1(z), f1(w), f1(10);

	f2(x), f2(z), f2(w);
	//f2(y);	CE: y is const but int &a not
	//f2(10);	CE: cannot bind non-const lvalue reference to prvalue

	f3(x), f3(y), f3(z), f3(w), f3(10);

	//f4(x);	can't bind
	//f4(y);	can't bind
	//f4(z);	can't bind rvalue reference to lvalue ***
	//f4(w);	can't bind rvalue reference to lvalue ***
	f4(10);


	return 0;
}

