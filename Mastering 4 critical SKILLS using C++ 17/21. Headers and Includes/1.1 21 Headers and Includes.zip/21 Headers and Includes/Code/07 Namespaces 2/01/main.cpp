#include <iostream>
#include <vector>
using namespace std;

#include "Employee.h"
using namespace OurSystem;

int main() {
	emp_glob->Print();

	return 0;
}
