#include <iostream>
#include <vector>
//using namespace std;

#include "Employee.h"
//using namespace OurSystem;

int main() {
	std::cout << "Hello world\n";

	OurSystem::Employee e("Belal");
	OurSystem::emp_glob->Print();

	return 0;
}
