#include <iostream>
#include "Employee.h"
using namespace std;

int main() {
	emp_glob->Print();

	return 0;
}
