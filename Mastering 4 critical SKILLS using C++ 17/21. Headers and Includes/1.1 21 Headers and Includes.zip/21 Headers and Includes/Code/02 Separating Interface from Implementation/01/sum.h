#ifndef SUM_H_
#define SUM_H_

// Declaration
// WHAT not How
int sum_1_n(int n);

#endif /* SUM_H_ */
