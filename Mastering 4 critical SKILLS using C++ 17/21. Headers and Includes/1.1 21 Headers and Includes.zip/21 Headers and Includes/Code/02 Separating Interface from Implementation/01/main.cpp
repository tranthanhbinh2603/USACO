
#include <iostream>
#include "sum.h"
using namespace std;

int main() {
	cout << sum_1_n(5) << "\n";

	return 0;
}
