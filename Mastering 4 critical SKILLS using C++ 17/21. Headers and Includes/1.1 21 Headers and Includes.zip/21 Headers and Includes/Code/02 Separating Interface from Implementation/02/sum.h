#ifndef SUM_H_
#define SUM_H_

// Declare - DON't initialize
extern int total_calls;

int sum_1_n(int n);

#endif /* SUM_H_ */
