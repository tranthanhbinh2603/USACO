/*
 * another.h
 *
 *  Created on: Oct 18, 2020
 *      Author: moustafa
 */

#ifndef ANOTHER_H_
#define ANOTHER_H_


void go();



#endif /* ANOTHER_H_ */
