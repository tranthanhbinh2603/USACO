#include "Department.h"

void Department::PrintDepartment() {
	cout << "Department: " << name << "\n";
}
