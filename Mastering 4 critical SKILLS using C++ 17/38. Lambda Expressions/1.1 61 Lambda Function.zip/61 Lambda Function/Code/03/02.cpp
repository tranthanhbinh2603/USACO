#include <iostream>
#include <vector>
using namespace std;

int main() {
	// Nested lambda
	vector<int> v { 1, 2, 3, 4 };

	[](auto &vec) {
		auto print = [](auto v) {cout <<v<<"\n";};

		for (auto item : vec)
			print(item);
	}(v);

	[](auto &vec) {
		for (auto item : vec)
			[](auto v) {cout <<v<<"\n";}(item);
	}(v);

	// In line 19 if you forgot to pass v:
	// CE: no match for call to (main()::<lambda(auto:3&)>) ()

	return 0;
}
