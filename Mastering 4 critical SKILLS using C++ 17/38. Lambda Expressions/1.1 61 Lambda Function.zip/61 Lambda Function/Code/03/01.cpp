#include <iostream>
#include <fstream>
#include <vector>
#include <memory>
using namespace std;

int main() {
	// Pointer to vec of length 20
	auto p = make_unique<vector<int> >(20);
	*p = {1, 2, 3, 4};
	int t = 1;

	// C++14: initialize (but assign) variables in []
	auto print = [x = 10, y = 2 * t, ptr = move(p)]() {
		for (auto &v : *ptr) {
			cout<<v<<" ";
		}
	};

	print();	// 1 2 3 4

	ofstream ofs("hello.txt");

	// CE: fstream cannot be copied
	//[ofs] () mutable {};

	[&ofs] () mutable {};	// Ok: but stream used after function

	[out = move(ofs)] () mutable {	// Ok & stream closed after it
		out<<"Hello world\n";
	};


	return 0;
}
