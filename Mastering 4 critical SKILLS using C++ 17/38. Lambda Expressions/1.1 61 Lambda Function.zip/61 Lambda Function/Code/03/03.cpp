#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

struct __lambda_unique_name {
	// For mutable: word const is removed
	void operator()(int i) const {
		cout << i;
	}
};

int main() {
	[](int i) {cout << i;};

	// Compiler does 2 things:
	// 1) generate a unique type that cannot be named: __lambda_unique_name

	// 2) generate an instance of the type
	__lambda_unique_name obj;
	obj(10);

	// If you try to capture variables, they will be members in the class

	// Future note:
	// lambdas without state capture = can be converted to function pointer

	return 0;
}
