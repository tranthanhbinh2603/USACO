#include <iostream>
#include <vector>
using namespace std;

int main() {
	int a = 1, b = 5;

	// [=] captures all local variables by VALUE
	[=]() {
		//++a; // CE
		cout<<a<<" "<<b<<"\n";	// 1 5
	} ();

	[=]() mutable {
		++a, ++b;
		cout<<a<<" "<<b<<"\n";	// 2 6
	} ();

	// [&] captures all local variables by REF
	[&]() {
		++a, ++b;
		cout<<a<<" "<<b<<"\n";	// 2 6
	} ();

	cout<<a<<" "<<b<<"\n";	// 2 6

	return 0;
}
