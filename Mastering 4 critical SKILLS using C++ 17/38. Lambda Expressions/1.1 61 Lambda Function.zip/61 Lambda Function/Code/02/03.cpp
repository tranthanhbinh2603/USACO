#include <iostream>
#include <vector>
using namespace std;

int main() {
	vector<int> vec {1, 2, 3, 4};

	int factor = 2;

	// [=] capture all local vars by value
	auto add_user_val = [=](auto &v)  {
		for (auto & item : v)
			item += factor;
	};

	add_user_val(vec);	// apply once: 3 4 5 6

	int sum = 0;
	// [&] capture all local vars by reference
	auto sum_oper = [&]()  {
		for (auto & item : vec)
			sum += item;
	};

	sum_oper();
	cout<<sum<<"\n";	// 18

	return 0;
}
