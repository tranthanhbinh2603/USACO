#include <iostream>
#include <vector>
using namespace std;

int main() {
	vector<int> vec {1, 2, 3, 4};

	int factor = 2, sum = 0;

	// [&sum] = pass by reference

	auto sum_oper = [&sum](auto &v)  {
		for (auto & item : v)
			sum += item;
	};
	sum_oper(vec);	// sum = 18

	[&factor, sum]()  {};	// factor by ref and sum by value

	return 0;
}
