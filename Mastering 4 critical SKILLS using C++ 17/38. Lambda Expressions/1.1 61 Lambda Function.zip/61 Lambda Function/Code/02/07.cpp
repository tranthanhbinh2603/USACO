#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;


int main() {
	int x = 0;
	static int y = 0;

	auto f = []() mutable {
		//++x; CE you must pass
		++y;	// static ok
	};

	f(), f(), f();	// y = 3

	return 0;
}
