#include <iostream>
#include <vector>
using namespace std;

class Employee {
private:
	int salary = 0;
	string name;

public:
	void hello() {
		// capture member variables by reference
		int a = 1, b = 5;
		auto f = [&a, this, b]() {
			salary = 20;
		};
		f();
		cout<<salary;
	}
};

int main() {
	Employee emp;
	emp.hello();

	return 0;
}
