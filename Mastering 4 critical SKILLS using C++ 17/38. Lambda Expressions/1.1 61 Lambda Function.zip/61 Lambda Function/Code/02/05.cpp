#include <iostream>
#include <vector>
using namespace std;

int main() {
	int a = 1, b = 5, c = 20;;

	// captures all by value, except c by reference
	[=, &c]() {
		c += 10;
	} ();
	// c = 30

	// captures all by ref, except b by value
	[&, b]() mutable{
		c += 10;
		b += 100;
	} ();
	// b = 5, c = 40


	return 0;
}
