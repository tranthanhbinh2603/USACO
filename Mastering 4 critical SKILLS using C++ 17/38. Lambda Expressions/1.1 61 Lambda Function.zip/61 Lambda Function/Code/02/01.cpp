#include <iostream>
#include <vector>
using namespace std;

int main() {
	vector<int> vec {1, 2, 3, 4};

	int factor = 2, sum = 0;

	// [] capture clause
	// You can pass parameters by CONST-by-value or reference
	auto add_user_val1 = [factor](auto &v)  {
		for (auto & item : v)
			item += factor;
		//factor++; // CE: read-only variable ‘factor’
	};
	add_user_val1(vec);	// apply once: 3 4 5 6

	// mutable: pass by value and allows internal updates for it
	auto add_user_val2 = [factor](auto &v)  mutable{
		for (auto & item : v)
			item += factor;
		factor = 1000;
	};
	add_user_val2(vec);
	cout<<factor<<"\n";	// still 2

	return 0;
}
