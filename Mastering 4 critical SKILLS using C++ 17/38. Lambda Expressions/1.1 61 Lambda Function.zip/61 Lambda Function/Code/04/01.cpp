#include <iostream>
#include <vector>
#include <sstream>
#include <algorithm>
using namespace std;

void Print1(auto ... args) {
    ((cout << args << ' '), ...);
    // Expansion
    // ((cout << 10 << ' '), ...);
    // ((cout << 10 << ' '), ((cout << 20 << ' '), ...));
    // ((cout << 10 << ' '), ((cout << 20 << ' '), ((cout << 30 << ' '))));
}

void LambdaPrint(auto ... args) {
	// Develop your logic for a single element
	auto PrintElement = [](const auto& x){
		// Let's decorate it
		ostringstream oss;
		oss<<"[[[{" << x <<"}]]]";

		cout << oss.str() << " ";
	};

	(PrintElement(args), ...);
}

void CaptureArgsInLambda(auto ... args) {
	auto f = [args...](){
		int sz = sizeof...(args);
		cout<<sz<<"\n";
	};
	f();
}

int main() {
	auto lambda = [](auto... args) {
		((cout << args << ' '), ...);
	};

	lambda(1, 2, 3);

	return 0;
}

