#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

bool IsOdd1(int n) {
	return n % 2 != 0;
}
int main() {
	vector<int> v { 1, 2, 3, 4, 5 };

	auto IsOdd2 = [] (int n) {return n % 2 != 0;};
	cout << count_if(v.begin(), v.end(), IsOdd2) << "\n"; // 3

	// Passing anonymous (unnamed) function object
	cout << count_if(v.begin(), v.end(), [] (int n) {return n % 2 != 0;}) << "\n";
	cout << IsOdd1(11) << "\n";
	cout << [] (int n) {return n % 2 != 0;}(11) << "\n";

	[]() {cout <<"anonymous\n";}   ();	// anonymous

	sort(begin(v), end(v),
			[](int i, int j) { return i > j; }
		);	// 5 4 3 2 1

	return 0;
}
