#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
	auto fsum2 = [](int x, int y) {
		return x + y;	// int data type
	};

	auto fsum3 = [](auto x, auto y) {
		return x + y;
	};

	cout<<fsum3(2, 4)<<" "<<fsum3(2.5, 3)<<"\n";	// 6 5.5

	auto fsum4 = [](auto x, auto y) noexcept {
		return x + y;
	};

	return 0;
}
