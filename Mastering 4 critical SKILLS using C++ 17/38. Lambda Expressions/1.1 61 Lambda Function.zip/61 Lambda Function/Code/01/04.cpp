#include <iostream>
#include <vector>
using namespace std;

// operation: Anything that act as a function
// 		Function pointer, functor, lambda
template<typename Function>
void foreach(vector<int> &vec, Function operation) {
	for (auto & item : vec)
		operation(item);
}

// You can't auto, but can use template
void square(int &x) {
	x = x * x;
}

struct AddOne {
	void operator () (auto &x) {
		++x;
	}
};

auto print = [](const auto x)  { cout<<x<<" ";   } ;

int main() {
	vector<int> vec {1, 2, 3, 4, 5};

	foreach(vec, AddOne());	// Functor
	foreach(vec, square);	// Function pointer

	foreach(vec,
			[](int &x) { --x; }
	);

	foreach(vec, print);	// 3 8 15 24 35


	return 0;
}
