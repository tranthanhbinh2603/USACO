#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int fsum1(int x, int y) {
	return x + y;
}

int main() {
	auto fsum2 = [](int x, int y) {
		return x + y;	// int data type
	};	// don't forget simicolon

	cout << fsum1(3, 6) << " " << fsum2(3, 6) << "\n";	//9

	// without -> int CE as ambiguous
	auto fsum3 = [](int x, int y) -> int {
		if (true)
			return 2.5;	// double return
		return  x + y;	// int return
	};

	// return type from braced-init-list is not valid
	//auto fsum4 = [](int x, int y)  {
	//	return {x, y, x+y};
	//};

	return 0;
}
