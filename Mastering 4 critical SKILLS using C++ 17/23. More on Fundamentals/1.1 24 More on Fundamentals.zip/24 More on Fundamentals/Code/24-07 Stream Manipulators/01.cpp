#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

int main() {

	cout << std::showpos;
	cout << 100 << "\n";		// +100
	cout << -100 << "\n";

	cout << std::noshowpos;
	cout << 100 << "\n";		// 100

	// setw: Create field of N slots for the NEXT one output
	cout << "[" << 1234 << "]\n";				// [1234]
	cout << "[" << setw(5) << 1234 << "]\n";	// [ 1234]
	cout << "[" << setw(6) << 1234 << "]\n";	// [  1234]
	cout << "[" << setw(7) << 1234 << "]\n";	// [   1234]

	cout << setiosflags(ios::left);
	cout << "[" << setw(7) << 1234 << "]\n";	// [1234   ]

	cout << 15 << "\n";										// 15
	cout << showbase << oct << 15 << "\n";					// 017
	cout << showbase << hex << 15 << "\n";					// 0xf
	cout << showbase << uppercase << hex << 15 << "\n";		// 0XF

	cout << "something" << endl << flush;

	return 0;
}
