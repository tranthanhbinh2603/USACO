#include <iostream>
#include <climits>	// const Limits
using namespace std;

int main() {

	long long var1 = 0;
	unsigned long long var2 = 0;
	unsigned long long int var3 = 0;	// same as above

	cout<<sizeof(var3);	// 8

	return 0;
}
