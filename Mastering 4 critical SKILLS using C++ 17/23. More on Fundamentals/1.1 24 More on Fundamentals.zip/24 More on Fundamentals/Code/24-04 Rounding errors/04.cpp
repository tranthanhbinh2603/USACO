#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

int dcmp(double a, double b, double EPS = 1e-10) {
	if (fabs(a - b) <= EPS)
		return 0;	// Equal
	if (a < b)
		return -1;	// smaller
	return 1;	// a > b
}

int main() {
	double a = 3.0 / 7.0;
	double b = 0.1 + 3.0 / 7.0 - 0.1;

	cout << (a == b) << "\n";			// 0
	cout << (dcmp(a, b) == 0) << "\n";	// 1

	cout << (dcmp(1.0/3.0, 0.33333333333333) == 0) << "\n";		// 1
	cout << (dcmp(1.0/3.0, 0.333333333) == 0) << "\n";			// 0
	cout << (dcmp(1.0/3.0, 0.333333333, 1e-9) == 0) << "\n";	// 1

	return 0;

	// 3 floating point data types
	double x { 10.0 };			// default
	float y { 20.f };			// NEVER use (!accurate), unless good reason
	long double z { 22.4L };	// Typically not needed

	cout << 3.33333333333333333333333333333333333333f << '\n';
	cout << 3.33333333333333333333333333333333333333 << '\n';
	cout << 3.33333333333333333333333333333333333333L << '\n';

	// 3.3333332538604736328 for float
	// 3.3333333333333334814 for double
	// 3.3333333333333333333 for long double
	// Observe: 1) NOT equal. 2) float is less accurate

	cout << setprecision(9); 	// Print 9 only
	float f { 123456789.0f }; 		// f has 10 significant digits
	cout << f << "\n";				// 123456792

	return 0;
}
