#include <iostream>
#include <iomanip>
using namespace std;

int main() {
	double c = 3.14159;
	cout << setprecision(5) << c << '\n';		// 3.1416
	cout << setprecision(9) << c << '\n';		// 3.14159
	cout << fixed;	// use with setprecision
	cout << setprecision(5) << c << '\n';		// 3.14159
	cout << setprecision(9) << c << '\n';		// 3.141590000

	// Rounding
	cout << setprecision(7) << 1.21658 << "\n";	// 1.2165800
	cout << setprecision(6) << 1.21658 << "\n";	// 1.216580
	cout << setprecision(5) << 1.21658 << "\n";	// 1.21658
	cout << setprecision(4) << 1.21658 << "\n";	// 1.2166
	cout << setprecision(3) << 1.21658 << "\n";	// 1.217
	cout << setprecision(2) << 1.21658 << "\n";	// 1.22
	cout << setprecision(1) << 1.21658 << "\n";	// 1.2
	cout << setprecision(0) << 1.21658 << "\n"; // 1

	cout << setprecision(3) << 1.21648 << "\n";	// 1.216

	return 0;

	// 3 floating point data types
	double x { 10.0 };			// default
	float y { 20.f };			// NEVER use (!accurate), unless good reason
	long double z { 22.4L };	// Typically not needed

	cout << 3.33333333333333333333333333333333333333f << '\n';
	cout << 3.33333333333333333333333333333333333333 << '\n';
	cout << 3.33333333333333333333333333333333333333L << '\n';

	// 3.3333332538604736328 for float
	// 3.3333333333333334814 for double
	// 3.3333333333333333333 for long double
	// Observe: 1) NOT equal. 2) float is less accurate

	cout << setprecision(9); 	// Print 9 only
	float f { 123456789.0f }; 		// f has 10 significant digits
	cout << f << "\n";				// 123456792

	return 0;
}
