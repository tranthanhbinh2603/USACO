#include <iostream>
#include <climits>	// const Limits
using namespace std;

int main() {
	for (double r = 0.0; r != 1.0; r += 0.5)
			cout << "*" << "\n";

	for (double r = 0.0; r != 1.0; r += 0.2)
			cout << "#" << "\n";

	for (double r = 0.0; r != 1.0; r += 0.1)
		cout << "$" << "\n";

	return 0;
}
