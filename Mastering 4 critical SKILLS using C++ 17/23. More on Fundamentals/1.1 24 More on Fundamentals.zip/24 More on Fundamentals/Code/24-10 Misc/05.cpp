#include <iostream>     // cout
#include <fstream>      // ifstream
using namespace std;

int main() {

	enum color {RED, GREEB, BLUE};	// 0, 1, 2

	color r = RED;
	cout<<r<<"\n";	//
	r = color(2);	// BLUE

	enum months1 {JAN=1, FEB, MAR, APR};	// 1, 2, 3, 4
	enum months2 {Feb = 2, Mar, Apr = 4};	// 2, 3, 4

	cout<<Mar;	// 3

	return 0;
}

