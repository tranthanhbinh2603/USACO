#include <iostream>
using namespace std;

inline int mymax(int a, int b)
{
	if(a > b)
		return a;
	return b;
}

int main() {
	cout<<mymax(2, 3);

	return 0;
}
