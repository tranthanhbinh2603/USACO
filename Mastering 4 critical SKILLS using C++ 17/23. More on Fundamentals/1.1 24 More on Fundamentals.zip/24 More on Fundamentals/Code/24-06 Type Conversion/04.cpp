#include <iostream>
#include <vector>
using namespace std;

int main() {

	vector<int> v;

	cout<<v.size() - 1<<"\n";

	for (int i = 0; i < (int)v.size() - 1; ++i)
		cout<<"#\n";

	for (int i = 0; i < v.size() - 1; ++i)
		cout<<"*\n";





	return 0;
}
