#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;


int main() {

	int age;
	cout << "Enter your age: ";
	cin >> age;

	string full_name;
	cout << "Enter full name: ";
	getline(cin, full_name);

	cout << "Your age: " << age <<
			" Your name: " << full_name << "\n";

	return 0;
}


