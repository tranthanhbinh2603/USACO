#include <iostream>
#include <cmath>
#include <sstream>
using namespace std;



int main() {
	char c = cin.peek();

	if (isdigit(c))
		cout << "Seems we will read integer\n";
	else
		cout << "hmm";

	string line;
	getline(cin, line);
	cout << line;	// full as inputed

	return 0;
}

