#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

void Read2Numbers(int &x, int &y) {
	while (true) {
		cin >> x >> y;

		if (cin.fail()) {
			cout << "Something wrong in input. Try again: ";
			cin.clear();	// refresh
			cin.ignore(256, '\n');
		} else
			break;
	}
}

int main() {

	int a, b;
	Read2Numbers(a, b);

	cout << a << " " << b;

	return 0;
}

