#include<iostream>
using namespace std;


int main()
{
	freopen("read_file.txt", "rt", stdin);

    freopen("my_output.txt", "wt", stdout);

	return 0;
}
