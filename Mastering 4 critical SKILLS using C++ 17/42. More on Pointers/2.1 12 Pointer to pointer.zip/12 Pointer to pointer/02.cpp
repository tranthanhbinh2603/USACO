#include <iostream>
#include <vector>
using namespace std;

int** Create(int rows, int cols) {
	// Create int* rows
	int **p { new int*[rows] { } };
	for (int i = 0; i < rows; ++i)
		p[i] = new int[cols] { };

	for (int i = 0; i < rows; ++i)
		for (int j = 0; j < cols; ++j)
			p[i][j] = 10 + i * j;
	// 0x78 0x6c 0x50 10
	cout<<&p<<" "<<p<<" "<<*p<<" "<<**p<<"\n";
	return p;
}
void Free2D(int **p, int rows) {
	// We CAN'T extract rows/cols from p
	// 2 delete[]
	for (int i = 0; i < rows; ++i)
		delete[] p[i];
	delete[] p;
}
int main() {
	int **p = Create(5, 9);
	Free2D(p, 5);

	return 0;
}
