#include <iostream>
#include <vector>
using namespace std;

int main() {

    int var = 10;
    int *ptr1 = &var;
    int **ptr2 = &ptr1;
    int ***ptr3 = &ptr2;

    cout<<&var<<" "<<var<<"\n";
    cout<<&ptr1<<" "<<ptr1<<" "<<*ptr1<<"\n";
    cout<<&ptr2<<" "<<ptr2<<" "<<*ptr2<<" "<<**ptr2<<"\n";
    cout<<&ptr3<<" "<<ptr3<<" "<<*ptr3<<" "<<**ptr3<<" "<<***ptr3<<"\n";

    /*
     	0x2008 						10
		0x4020 				 0x2008 10
		0x3096 		  0x4020 0x2008 10
		0x5555 0x3096 0x4020 0x2008 10

		Chain of pointers
			Each pointer has an address
			And looking to an address that has value
				value can be another address of a pointer
				or finally a value
     */



	return 0;
}
