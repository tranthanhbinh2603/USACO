#include<iostream>
#include<vector>
using namespace std;

template<typename T>
void templated_fn(T lst) {
	for (auto item : lst)
		cout << item << " ";
	cout << "\n";
}

int main() {
	// templated_fn({1, 2, 3}); // CE

	templated_fn<initializer_list<int>>( { 1, 2, 3 });
	templated_fn<vector<int>>( { 1, 2, 3 });

	return 0;
}
