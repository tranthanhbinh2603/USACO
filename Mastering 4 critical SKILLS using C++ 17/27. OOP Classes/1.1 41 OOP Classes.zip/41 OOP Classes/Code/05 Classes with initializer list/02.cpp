#include<iostream>
#include<vector>
using namespace std;

// https://www.bogotobogo.com/cplusplus/C11/C11_Uniform_initialization.php

struct A {
	int x, y;
};
struct B {
	int x, y;
	B(int x, int y) : x { x }, y { y } {}

};
struct C {
	int x, y;
	C(int x, int y) : x { x }, y { y } { }
	C(const initializer_list<int>& v) {
		x = *(v.begin()), y = *(v.begin() + 1);
	}
};
int main() {
	A a { 1, 3 };	// Aggregate initialization
	B b { 2, 9 };	// Regular constructor
	C c1 { 3, 7 };	// Initializer_list
	C c2 (3, 7);	// Regular constructor

	// Priority: initializer_list, regular, aggregate

	return 0;
}
