#include <iostream>
#include <vector>
#include <sstream>
#include <algorithm>
using namespace std;

class A {
public:
	A() {	}	// user-provided constructor
	int i;
	string s;
};
class B {
public:
	// NOT user-provided constructor
	// implicit generated default constructor
	int i;
	string s;
};

class C {
public:
	// NOT user-provided constructor
	C() = default;	// assign default values
	int i;
	string s;
};
class D {
public:
	// user-provided constructor ... OOPS
	D();
	int i;
	string s;
};
D::D() = default;

int main() {
	vector<int> v(1000);

	for (int i = 0; i < 100; ++i) {
		// Default-initialization - undermined value
		A a1;
		B b1;
		C c1;
		D d1;
		cout << a1.i <<"\n";	// typically garbage
		cout << b1.i <<"\n";	// typically garbage
		cout << c1.i <<"\n";	// typically garbage
		cout << d1.i <<"\n";	// typically garbage

		// Value-initialization triggered by () or {}
		A a2 {};
		B b2 {};
		C c2 {};
		D d2 {};
		cout << a2.i <<"\n";	// still garbage
		cout << b2.i <<"\n";	// always 0
		cout << c2.i <<"\n";	// always 0
		cout << d2.i <<"\n";	// still garbage

		// s ALWAYS = "" as its default constructor is called
	}

	// Do your self favor. Always initialize variables, better using {} style
	return 0;
}

