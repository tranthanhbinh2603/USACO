#include <iostream>
#include <vector>
#include <sstream>
#include <algorithm>
using namespace std;

class Employee {
private:
	int * salary { nullptr };
	string name;
public:
	Employee() = default;

	Employee(const Employee&) = delete;

	Employee(int salary, string name) :
			salary(new int { salary }), name(name) {
	}
	~Employee() {
		if (salary != nullptr) {
			delete salary;
			salary = nullptr;
		}
	}
};

int main() {
	Employee e1(10, "Mostafa");

	// Line 14 prevents it
	//Employee e2(e1);



	return 0;
}

