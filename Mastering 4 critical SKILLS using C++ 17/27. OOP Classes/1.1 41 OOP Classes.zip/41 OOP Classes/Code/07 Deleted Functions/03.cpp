#include <iostream>
#include <vector>
#include <sstream>
#include <algorithm>
using namespace std;

class Employee {
private:
	int * salary { nullptr };
	string name;
public:
	Employee() = default;

	void Hello(int x)  {}
	void Hello(double x)  = delete;

	Employee(int salary, string name) :
			salary(new int { salary }), name(name) {
	}
	~Employee() {
		if (salary != nullptr) {
			delete salary;
			salary = nullptr;
		}
	}
};

int main() {
	Employee e1(10, "Mostafa");

	e1.Hello(10);

	// Line 15 prevents it
	//e1.Hello(10.5);



	return 0;
}

