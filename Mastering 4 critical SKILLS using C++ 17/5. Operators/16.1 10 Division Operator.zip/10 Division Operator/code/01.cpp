#include<iostream>
using namespace std;

int main() {
	cout << 25 / 5 << "\n";
	cout << 26 / 5 << "\n";
	cout << 27 / 5 << "\n";
	cout << 28 / 5 << "\n";
	cout << 29 / 5 << "\n";
	cout << 30 / 5 << "\n";
	cout << 31 / 5 << "\n";
	cout << "******\n";
	cout << 25 / 5.0 << "\n";
	cout << 26 / 5.0 << "\n";
	cout << 27.0 / 5 << "\n";
	cout << 28.0 / 5.0 << "\n";
	cout << 29.0 / 5.0 << "\n";
	cout << 30.0 / 5.0 << "\n";
	cout << 31.0 / 5 << "\n";

	return 0;
}

