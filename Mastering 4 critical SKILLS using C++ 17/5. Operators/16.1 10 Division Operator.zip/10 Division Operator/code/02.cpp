#include<iostream>
using namespace std;

int main() {
	int num { 12345 };

	cout<<num/10<<"\n";
	cout<<num/100<<"\n";
	cout<<num/1000<<"\n";
	cout<<num/10000<<"\n";
	cout<<num/100000<<"\n";

	cout<<"*********\n";

	cout<<num/10.0<<"\n";
	cout<<num/100.0<<"\n";
	cout<<num/1000.0<<"\n";
	cout<<num/10000.0<<"\n";
	cout<<num/100000.0<<"\n";


	return 0;
}

