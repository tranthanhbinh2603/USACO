#include<iostream>
using namespace std;

int main() {
	cout << (3 > 5) << "\n";
	cout << (3 < 5) << "\n";
	cout << (3 == 5) << "\n";
	cout << (3 >= 5) << "\n";
	cout << (3 >= 3) << "\n";
	cout << (3 == 3) << "\n";
	cout << (3 > 1) << "\n";
	cout << (3 != 4) << "\n";
	cout << (3 != 3) << "\n";

	return 0;
}
