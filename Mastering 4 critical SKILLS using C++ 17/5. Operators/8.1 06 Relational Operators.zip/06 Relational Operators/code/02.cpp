#include<iostream>
using namespace std;

int main() {
	int x, y;
	x = 3, y = 5;

	cout << (x > y) << "\n";
	cout << (x < y) << "\n";
	cout << (x == y) << "\n";
	cout << (x >= y) << "\n";

	return 0;
}
