#include<iostream>
using namespace std;

int main() {
	int salary;
	cin>>salary;

	if (salary < 1000)
		cout<<"you are poor\n";

	cout<<"Salam";

	return 0;
}

