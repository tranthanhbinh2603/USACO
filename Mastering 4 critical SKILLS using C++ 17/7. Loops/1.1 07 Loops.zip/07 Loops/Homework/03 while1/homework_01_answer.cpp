#include<iostream>
using namespace std;

int main() {
	int start, end;

	cin>>start>>end;

	while(start <= end)
	{
		cout<<start<<"\n";
		start++;
	}

	return 0;
}

