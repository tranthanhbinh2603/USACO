#include<iostream>
using namespace std;

int main() {
	int x = 1;

	while (x <= 5)
	{
		cout << x << " ";
		x = x + 1;
	}

	return 0;
}
