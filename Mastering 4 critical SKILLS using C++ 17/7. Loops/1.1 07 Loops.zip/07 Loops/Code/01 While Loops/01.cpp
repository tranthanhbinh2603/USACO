#include<iostream>
using namespace std;

int main() {

	while (2 < 6)
	{
		cout<<"2 < 5. Forever\n";
	}

	return 0;
}
