#include<iostream>
using namespace std;

int main() {
	int sum = 0;

	for (int x = 1; x < 6; ++x)
		sum += x;

	cout<<sum;

	return 0;
}
