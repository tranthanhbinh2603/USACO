#include <iostream>
using namespace std;

struct Employee {
	int id;
	Employee(int id_) {
		id = id_;
	}
	~Employee() {
		cout << "Destroy Employee " << id << "\n";
	}
};

void f4() {
	cout << "Start f4\n";
	Employee *p = new Employee(4);
	throw 1;
	// Memory LEAK
	delete p;	// never execute
	cout << "End f4\n";
}
void f3() {
	cout << "Start f3\n";
	Employee p(3);
	f4();
	cout << "End f3\n";
}
void f2() {
	cout << "Start f2\n";
	try {
		f3();
	} catch (runtime_error &e) {
		// won't match - no effect
		cout << "runtime_error :"
			 << e.what() << "\n";
	}
	cout << "End f2\n";
}
void f1() {
	cout << "Start f1\n";
	try {
		f2();
	} catch (int &e) {	// match stop it here
		cout << "error code:" << e << "\n";
	}
	cout << "End f1\n";
}

int main() {
	f1();

	return 0;
}
