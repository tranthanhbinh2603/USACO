#include <iostream>
using namespace std;

struct Name {
	string first;
	Name() {}
	Name(string first_) { first = first_;	}
	~Name() { cout << "Name Destructor "<<first<<"\n";	}
};
struct Employee {
	Name* full_name1 { };
	Name full_name2;

	Employee() {
		full_name1 = new Name("Mostafa");
		throw 0;	// memory leak
		full_name2.first = "Belal";
	}
	~Employee() {	// never called
		delete full_name1;
		cout << "Destroy Employee \n";
	}
};
int main() {
	try {
		Employee();
	} catch(...) {

	}
	return 0;
}
