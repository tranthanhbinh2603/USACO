#include <iostream>
using namespace std;

struct BankAccount {
	int money = 1000;
	bool PayBill(int bill_value) {
		if (bill_value < 0)
			throw invalid_argument("Bill Value can't be negative!");
		if (money >= bill_value) {
			money -= bill_value;
			return true;
		} else
			return false;
	}
};
int main() {
	BankAccount acct;
	try {
		cout << acct.PayBill(100) << "\n";
		cout << acct.PayBill(500000) << "\n";
		cout << acct.PayBill(-10) << "\n";
		cout << acct.PayBill(200) << "\n";
	} catch (invalid_argument &e) {
		cout << "Caught an exception: " << e.what() << "\n";
		throw e;	// I don't want to handle
	}
	cout << "Bye";

	return 0;
}
