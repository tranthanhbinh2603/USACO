#include <iostream>
using namespace std;

int* CreateArrayOnMobile(int len) {
	if (len <= 0)
		throw 17;	// Some error code
	if (len >= 10000)
		throw runtime_error("Too big array for this mobile memory");
	return new int[len];
}
int main() {
	int *p = nullptr;
	try {
		int *p = CreateArrayOnMobile(-10);
	} catch (runtime_error &e) {
		cout << "runtime_error :" << e.what();
	} catch (...) {
		cout << "Caught unknown exception type!\n";
	}
	if (p != nullptr) {	// only if created!
		delete[] p;
		p = nullptr;
	}

	return 0;
}
